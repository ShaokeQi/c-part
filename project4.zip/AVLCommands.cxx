#include "AVL.h"
#include "json.hpp"
#include <fstream>
#include <iostream>

int main(int argc, char** argv)
{

    if(argc != 2){//this line checks whether the argc variable is not equal to 2
        std::cerr << "Usage: AVLCommands file.json" << std::endl;//messgae
        exit(-1);//this line termiates the program with an exit 
    }//end if

    std::string filename = argv[1]; //name of file

    std::ifstream file(filename); //read stream for file
    nlohmann::json in_json; //read json for file
	//check if the file opens right
    if(file.is_open()){//check file is open or not
        file >> in_json; //read file
    }//end if
    else{//else statement
        std::cerr << "Error: cannot open file " << filename << std::endl;//error message
		exit(-1);//exit status with -1
    }//end if 

    
    AVL tree;//int numOperations = in_json["metadata"]["numOperations"];
    for(auto itr = in_json.begin(); itr != in_json.end(); itr++){//this line checks whether the first character of the key of the current element is not equal to the characther m
		//check sample
        if(itr.key()[0] != 'm'){//check sample
            if(itr.value()["operation"] == "Insert"){//value of the current elemtn is equal to the string insert. is so, the ncode proceeds to insert the key value of the current element into the avl tree
                tree.Insert(static_cast<int>(itr.value()["key"]));//this line inserts the key value of current element in to the avl tree, after casting it to the interger using static cast
            }//end if
        }//end if
    }//end loop

    std::cout << tree.JSON();//this line print the json represnetation of the avl tree to the standard output steam
    return 0;//finished main fucntion
}
