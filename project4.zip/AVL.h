#ifndef AVL_H_INCLUDED
#define AVL_H_INCLUDED

#include <memory>
#include <string>

class AVL;
class AVLNode{//class AVL node
public:// public access
    AVLNode(int key);//this is a constructor for avl node that takes an interger argument key
    AVLNode(int key, std::weak_ptr<AVLNode> parent);//this is another constructor for avlnode that take 2 arguemtn
    bool IsLeaf() const;//this is member fucntion of avlnode that returns a boolean value indicatinf whether the node is a leaf
    bool HasLeftChild() const;//this is another member function of avlnode that returns a boolean value indicating whether the node has left child
    bool HasRightChild() const;//this is another member function of avlnode that returns a boolean value indicating whether the node has right child

private://private access
    int key_;//these lines declare the private member variables of the avlnodeclass
    std::weak_ptr<AVLNode> parent_;// smart pointer to parent
    std::shared_ptr<AVLNode> left_;// smart pointer to left
    std::shared_ptr<AVLNode> right_;// smart pointer to right child
    int height_;//also smater pointer to track the height of the node

    friend AVL;// the friend keyword is used to allow the avl class to access the privaye member variable of avlnode
};  //AVL node

class AVL{//class
public://public access
    AVL();//this is the defualt consttuctor for avl
    void Insert(int key);//this is a fucntion fo avl that taks an interger key as an argument and inserts a new node with that key into the tree/
    std::string JSON() const;//this is another member function of avl that returns a string reoresentation of the tree in Json format.
    size_t size() const;//this is member function of avl that returns the number of nodes in the tree/
    bool empty() const;// this is a member function of avl that returns a voolean value indicating whether the tree is empty

private://private access //this is a private member function of avl that take a shate_ptr to an avlnode as an argument and returns the height of that node.
    int Height(std::shared_ptr<AVLNode> x) const;//the balance factor of a node is defined as the difference between the heights of its left and right subtrees
    int GetBalance(std::shared_ptr<AVLNode> x) const;////this is a private member function of avl that take a shate_ptr to an avlnode as an argument and returns the height of that node.
    std::shared_ptr<AVLNode> LeftRotate(std::shared_ptr<AVLNode> y);//this is another private member fucntion of avl that performs a left rotation on the subtree rooted at the node y
    std::shared_ptr<AVLNode> RightRotate(std::shared_ptr<AVLNode> y);//this is private member function of avl that performs a right rotation on the subtree rooted at the node y
    std::shared_ptr<AVLNode> RecursiveInsert(std::shared_ptr<AVLNode> cur, int key); //recursive function to insert key
    std::shared_ptr<AVLNode> root_;//this is a private member variable of avl that points to root node of the ttree
    size_t size_;// another private member
};//end class

#endif // AVL_H_INCLUDED
