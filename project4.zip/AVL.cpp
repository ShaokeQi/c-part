#include "AVL.h"
#include "json.hpp"
#include <queue>
#include <iostream>

AVLNode::AVLNode(int key): key_(key),//this is constructor
    parent_(std::weak_ptr<AVLNode>()),//for the avlnode class that take following arguments
    left_(nullptr),//iniialized
    right_(nullptr),//initialized
    height_(0)//initialized to 0
{}

AVLNode::AVLNode(int key, std::weak_ptr<AVLNode> parent): key_(key),//this is constructor
    parent_(parent),//for the avlnode class that take following arguments
    left_(nullptr),//iniialized
    right_(nullptr),//initialized
    height_(0)//initialized to 0
{}

bool AVLNode::IsLeaf() const{//this fucntion return ture if the node does not have any children, indicating tha tit is aleaf
    return left_ == nullptr && right_ == nullptr;//this fucntion return ture if the node does not have any children, indicating tha tit is aleaf
}//end fucntion

bool AVLNode::HasLeftChild() const{//fucntion
    return left_ != nullptr;//this function returns true if the node has a left child indicating that is is not a leaf and has a left subtree
}//end fucntion

bool AVLNode::HasRightChild() const{//function
    return right_ != nullptr;//this fucntion returns true is the node has atight child indicating that is not a leaf and has a right subtree otherwise false
}//end function


AVL::AVL(): root_(nullptr), size_(0){}//root_ initialized to nullptr size_initialized to 0

int AVL::Height(std::shared_ptr<AVLNode> x) const{//this is a private member fucntion of the avl class that takes a std::shared_ptr to an avl node obkect x and returns an int value indicating the height of node
    if(x == nullptr){//check x if the node is a nullptr meaning it is an empty tree or subtree
        return -1;//if so, it returns -1
    }//end if
    return x->height_;//it returns the value of the height_ member variable of node
}//end function
int AVL::GetBalance(std::shared_ptr<AVLNode> x) const{//this is private member function of the avl class that take a std::shared_ptr to an avlnode object x and return an int value indicating the balance factor of the node.
    if(x == nullptr){//check if node is a nullptr, meaning it is an emptu trr or subtree
        return 0;//if so it return 0 to indicate that the balance factor is 0
    }//end if
    return Height(x->right_) - Height(x->left_);//otherwise it returns the difference between the height of the right subtree and the height of the left subree
}//end fucntion

//let us define the rotate node is x and y is its parent, that is x is y's child
std::shared_ptr<AVLNode> AVL::RightRotate(std::shared_ptr<AVLNode> y){//this lien declares the functino rr which takes a shared pointer y to an avlnode object and returns a shared pointer to a navlnode object
    //perform rotation
    std::shared_ptr<AVLNode> x = y->left_;//this line created a shared pointer x to the left child of y
    y->left_ = x->right_;//these two lines perform the rr around y by undating its left child to be x 
    x->right_ = y;//x'right child and updating x right child to be y

    if(y->left_ != nullptr){//this condictional statement checjs if y has left child. if it does, it updates the left child's parent pointer to point to y
        y->left_->parent_ = y;//this condictional statement checjs if y has left child. if it does, it updates the left child's parent pointer to point to y
    }//end if

    x->parent_ = y->parent_;//these two lines update the parent pointers of x and y to reflect the new tree
    y->parent_ = x;//x's parent pointer is set to y 's parent pointer and y's parent pointer is set to x

    //update height
    y->height_ = std::max(Height(y->left_), Height(y->right_)) + 1;//this lines update the height of y and x by calling the height() function and taking the maximum of the heights of their ledt and right subtrees.
    x->height_ = std::max(Height(x->left_), Height(x->right_)) + 1;//this lines update the height of y and x by calling the height() function and taking the maximum of the heights of their ledt and right subtrees.

    return x;//this line returns the shared pointer x, which now points to be the node that was rotated up to become the new partent

}//end fucntion

//let us define the rotate node is x and y is its parent, that is x is y's child
std::shared_ptr<AVLNode> AVL::LeftRotate(std::shared_ptr<AVLNode> y){//function signature, declares the function name and input parameter y

    std::shared_ptr<AVLNode> x = y->right_;//create a shared pointer x to the right child of y

    //perform rotation
    y->right_ = x->left_;//set the right child of y to be the ledt child ofx
    x->left_ = y;//set the left child of x to be y

    if(y->right_ != nullptr){//if y has right child, set its parent to be y
        y->right_->parent_ = y;//set the patent of y to be x
    }//end if
    x->parent_ = y->parent_;//set the parent of x to be parent of y
    y->parent_ = x;//set the patent of y to be x

    //update height
    y->height_ = std::max(Height(y->left_), Height(y->right_)) + 1;//update the height of y
    x->height_ = std::max(Height(x->left_), Height(x->right_)) + 1;//update height ofx


    return x; //returnr the shated pointer to the new root of the rotated subtree.
}//end funcntion

std::shared_ptr<AVLNode> AVL::RecursiveInsert(std::shared_ptr<AVLNode> cur, int key){//fucntion
    if(cur == nullptr){//if current node is null
        return std::make_shared<AVLNode>(key);//the na new node with given key is created and returned as root of the tree
    }//endif

    //insert left
    if(key < cur->key_){//this node recursively on either the left or right subtree of the current depending on whether the given key is less than or greter than current node's key.
        std::shared_ptr<AVLNode> left = RecursiveInsert(cur->left_, key);//this node recursively on either the left or right subtree of the current depending on whether the given key is less than or greter than current node's key.
        left->parent_ = cur;//the resulting subtree is the nattached to the appropriate child pointer
        cur->left_ = left;//the resulting subtree is the nattached to the appropriate child pointer
    }//end if
    else{//else statement
        std::shared_ptr<AVLNode> right = RecursiveInsert(cur->right_, key);//this node recursively on either the left or right subtree of the current depending on whether the given key is less than or greter than current node's key.
        right->parent_ = cur;//same with line 101
        cur->right_ = right;//same with line 102
    }

    cur->height_ = std::max(Height(cur->left_), Height(cur->right_)) + 1;//after inserting the new node, the height of the current node is updated by taking the max height of its left and right subtrees, adding 1

    //left left case
    if(GetBalance(cur) < -1 && key < cur->left_->key_){//if the balance factor of the current node is less than -1
        return RightRotate(cur);//the rr is performed on the current node to balance the tree
    }//end if

    //right right case
    if(GetBalance(cur) > 1 && key >= cur->right_->key_){//if the balance factor of the current node is less than -1
        return LeftRotate(cur);//the LL is performed on the current node to balance the tree
    }//end if
    //left right case
    if(GetBalance(cur) < -1 && key >= cur->left_->key_){//if < -1
        std::shared_ptr<AVLNode> left = LeftRotate(cur->left_);//LR 
        left->parent_ = cur; //given key is greteater than or equal to the key of the current node's left child
        cur->left_ = left;//then left rotation is performed on the curretn node's left child
        return RightRotate(cur);//perfomed RR
    }//end if

    //right left case
    if(GetBalance(cur) > 1 && key < cur->right_->key_){//if balance factor of current node is >1 and the given key is less than key of the current node's right child
        std::shared_ptr<AVLNode> right = RightRotate(cur->right_);//if balance factor of current node is >1 and the given key is less than key of the current node's right child
        right->parent_ = cur;//then a right rotation is perform on the current node
        cur->right_ = right;//then a right rotation is perform on the current node
        return LeftRotate(cur);//then a right rotation is perform on the current node
    }//end if

    return cur;//return current node
}

void AVL::Insert(int key){//is fucntion of avl that take an int key value to be inserted into the tree
    root_ = RecursiveInsert(root_, key);//which updates the root of the avl tree
    size_++;//incremented
}//end fucntion
size_t AVL::size() const{//funciton
    return size_;//return the value of the private data member size_
}//end fucntion 
bool AVL::empty() const{//fucntion of avl class tha treturn a boolean value indicating whether the avl tree is empty or not
    return size_ == 0;//member variable is qual to 0
}//end fucntino

std::string AVL::JSON() const{//function
    nlohmann::json result;//creates an empty json object named result
	std::queue< std::shared_ptr<AVLNode> > nodes;//create an emty queue of shared pointer to avlnodes named nodes
	if (root_ != nullptr) {//check if the avl tree is not empty
        result["root"] = root_->key_;//adds the key value of the root ndoe to the result obeject as root
		nodes.push(root_);//adds the root node to the nodes queue
		while (!nodes.empty()) {//while is not empty 
			auto v = nodes.front();//retrieve the next node in the queue and assigns it to v
			nodes.pop();//remove the node v from fron of queue
			std::string key = std::to_string(v->key_);//converts the key value of node v to a string and assigns it to key
			if (v->left_ != nullptr) {//checks if node v has sa left child
				result[key]["left"] = v->left_->key_;//adds the key value of the left child of node v to the result object
				nodes.push(v->left_);//adds the tight child of node v to the node queue
			}//end if 
			if (v->right_ != nullptr) {//checks if node v has a parent
				result[key]["right"] = v->right_->key_;//adds the key value of the parent of node v to the result object under the key "parent" at the location
				nodes.push(v->right_);//adds the right child of node v to the nodes queue.
			}//end if
			if (v->parent_.lock() != nullptr) {//checks if node v has a parent.
				result[key]["parent"] = v->parent_.lock()->key_;//adds the key value of the parent of node v to the result object under the key "parent" at the location identified by key.
			} else {//else statement //end if
				result[key]["root"] = true;//If the parent is null, the "root" field of the result object is set to true.
			}//end else
			result[key]["height"] = Height(v);//Adds the height of node v to the result object under the "height"
			result[key]["balance factor"] = GetBalance(v);
		}//end while
	}//end if
	result["height"] = Height(root_);//Sets the "height" field of the JSON object to the height of the AVL tree
	result["size"] = size_;//Sets the "size" field of the JSON object to the size of the AVL tree
	return result.dump(2) + "\n";//Formats the JSON object as a string with an indentation level of 2 and a newline character at the end, then returns the string.
}