#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <array>
#include <ctime>
#include <iomanip>
#include "json.hpp"
#include "insertionsort.h"
#include "mergesort.h"
#include "quicksort.h"

int main(int argc, char** argv) {//The function definition specifies that it takes two parameters
    //check number of arguments
    if(argc != 2){//check number of arguments if the number of arguments is not equal to 2, the code inside the "if" block is executed.
        std::cerr << "Usage: timealgorithms file.json" << std::endl;//the message "Usage: timealgorithms file.json" is printed to indicate the correct usage of the program
        exit(-1);//call terminates the program and returns the value -1 to the operating system, indicating an error
    }//end if

    std::string filename = argv[1];//name of file
    //std::string filename = "Example1.json";
    //std::string filename = "SampleExample.json";
    std::ifstream file(filename);//read json for file
    nlohmann::json in_json;//read json for file
    nlohmann::json out_json;//out json
    if(file.is_open()){//check if the file opens right
        file >> in_json;//read file
    }//end if
    else{//if not then else
        std::cerr << "Error: cannot open file " << filename << std::endl;//if else print we cannot open the file
    }//end else

    file.close();//close file


    //int n = in_json["metadata"]["arraySize"];

    std::cout << "Sample,InsertionSortTime,InsertionSortCompares,InsertionSortMemaccess,MergeSortTime,MergeSortCompares,MergeSortMemaccess,QuickSortTime,QuickSortCompares,QuickSortMemaccess" << std::endl;//The output string contains a header for a table that lists the measurement results for three sorting
    for(auto itr = in_json.begin(); itr != in_json.end(); itr++){//iterate
        if(itr.key()[0] == 'S'){//if statement checks the first character of the key returned by itr.key(). If the first character is 'S' then the code inside the "if" block is executed.
            std::vector<int> array1;//copy data
            std::vector<int> array2;//copy data
            std::vector<int> array3;//copy data
            std::cout << itr.key();//output key
            for(auto e : itr.value()){// The for loop iterates over each element e in the array-like object returned by itr.value()
                array1.push_back(e);//each vector to add the element e to the end of the vector
                array2.push_back(e);//each vector to add the element e to the end of the vector
                array3.push_back(e);//each vector to add the element e to the end of the vector
            }// end  for
            //insertion sort
            {
                std::pair<int, int> counts;//declares a pair that stores two integer values
                auto start = clock();//initializes it with the value returned by the clock function.
                InsertionSort(&array1, counts);//It is likely that the InsertionSort function modifies the elements in the vector array1
                auto end = clock();//get the end time
                std::cout << "," << std::setiosflags(std::ios::fixed) << std::setprecision(6) <<  1.0 * (end - start) / CLOCKS_PER_SEC << "," << counts.first << "," << counts.second;//Let's print the corresponding comparison count, memory access count 

            }
            //merge sort
            {
                std::pair<int, int> counts;//declares a pair that stores two integer values
                auto start = clock();//initializes it with the value returned by the "clock" function.
                MergeSort(&array2, counts);//It is likely that the "mergeSort" function modifies the elements in the vector "array2"
                auto end = clock();//get the end time
                std::cout << "," << std::setiosflags(std::ios::fixed) << std::setprecision(6) <<  1.0 * (end - start) / CLOCKS_PER_SEC << "," << counts.first << "," << counts.second;//Let's print the corresponding comparison count, memory access count

            }
            //quicksort
            {
                std::pair<int, int> counts;//declares a pair that stores two integer values
                auto start = clock();//initializes it with the value returned by the "clock" function.
                QuickSort(&array3, counts);////It is likely that the "QuickSort" function modifies the elements in the vector "array3"
                auto end = clock();//get the end time
                std::cout << "," << std::setiosflags(std::ios::fixed) << std::setprecision(6) <<  1.0 * (end - start) / CLOCKS_PER_SEC << "," << counts.first << "," << counts.second;//Let's print the corresponding comparison count, memory access count

            }



            std::cout << std::endl;//The purpose of this line of code is to move the cursor to the next line, so that the next output to std::cout will appear on a new line.
        }

    }

    return 0;//main end
}
