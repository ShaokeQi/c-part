#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <array>
#include <unordered_set>
#include "json.hpp"



int main(int argc, char** argv) {//signature specifies that the main function takes two arguments
    if(argc != 3){//check number of arguments
        std::cerr << "Usage: consistentresultverification file1.json file2.json" << std::endl;// this just message notice
        exit(-1);//exit
    }

    std::string filename1 = argv[1]; //file1
    std::string filename2 = argv[2]; //file2
    //std::string filename1 = "SampleExample.json";
    //std::string filename2 = "AlmostSampleExample.json";
    //std::string filename1 = "Example1.json";
    //std::string filename2 = "Example2.json";
    std::ifstream file1(filename1);//read stream for file1
    std::ifstream file2(filename2);//read stream for file 2
    nlohmann::json in_json1;//read json for file 1
    nlohmann::json in_json2;//read json for file2
    nlohmann::json out_json;//out json for output
    if(file1.is_open()){//if case:file1 open
        file1 >> in_json1;//read file1
    }
    else{
        std::cerr << "Error: cannot open file " << filename1 << std::endl;//error message
        exit(-1);//exit
    }

    if(file2.is_open()){//check if the file2 opens right
        file2 >> in_json2;//read file2
    }
    else{
        std::cerr << "Error: cannot open file " << filename2 << std::endl;//error message
        file1.close();//close the file
        exit(-1);//exit
    }

    file1.close();//file1 close
    file2.close();//file2 close

    out_json["metadata"]["File1"]["arraySize"] = in_json1["metadata"]["arraySize"];//basic infomarion for file1 and file2 to out json//print size
    out_json["metadata"]["File1"]["numSamples"] = in_json1["metadata"]["numSamples"];//print numsamples
    out_json["metadata"]["File1"]["name"] = filename1;//print name

    out_json["metadata"]["File2"]["arraySize"] = in_json2["metadata"]["arraySize"];//basic infomarion for file1 and file2 print size
    out_json["metadata"]["File2"]["numSamples"] = in_json2["metadata"]["numSamples"];//print numsamples
    out_json["metadata"]["File2"]["name"] = filename2;//print name
    int n = in_json1["metadata"]["arraySize"];//array size
    int samplesWithConflictingResults = 0;//samples with conflictinf results
    //iterate json for file1
    for(auto itr = in_json1.begin(); itr != in_json1.end(); itr++){// itr from begin to end and itr++
        if(itr.key()[0] == 'S'){//checksample
            std::vector<std::pair<std::string, std::array<int, 2>>> diff;//vector for different pair
            //loop to look for different pair
            for(int i = 0; i < n; i++){//just build for loop
                if(itr.value()[i] != in_json2[itr.key()][i]){//just different value
                    diff.push_back({std::to_string(i), {itr.value()[i], in_json2[itr.key()][i]}});//add pair
                }//end if loop
            }//end for loop
            //output the diff to out_json
            if(diff.size() != 0){
                samplesWithConflictingResults++;//add sampleswithconfiltingresults
                out_json[itr.key()][filename1] = itr.value();//add value to filename1
                out_json[itr.key()][filename2] = in_json2[itr.key()];//add value to filename2
                //get dismatch
                for(auto& e : diff){//this all for loop is about get dismatch
                    out_json[itr.key()]["Mismatches"][e.first] = e.second;//assignment. getmatch
                }//end for loop
            }//end if loop
        }//end if loop
    }//end for loop
    out_json["metadata"]["samplesWithConflictingResults"] = samplesWithConflictingResults;//get sample with
    std::cout << out_json.dump(2) << std::endl;//output result

    return 0;//what can i say
}
