// Insertion Sort
//
// Author: Rob Gysel
// ECS60, UC Davis
// Adapted from: Lysecky & Vahid "Data Structures Essentials", zyBooks

#include <vector>
#include "json.hpp"

void InsertionSort(std::vector<int>* numbers, std::pair<int, int>& counts);
