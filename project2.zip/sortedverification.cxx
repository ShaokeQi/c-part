#include<iostream>
#include <string>
#include <fstream>
#include <vector>
#include <array>
#include "json.hpp"

bool isSorted(const std::vector<int>& v){//check if the vector is sorted
    size_t n = v.size();//assignment the size
    if(n < 2){//if size is less than2 it is sorted
        return true;//If it is, the function returns true.
    }//end if
    for(size_t i = 0; i < n - 1; i++){//check if the next element is larger than current element
        if(v[i] >= v[i + 1]){//like value on index0 > index1
            return false;//if it is return false
        }//end if 
    }//end for loop
    return true;//bool function
}

int main(int argc, char** argv) {//The function definition specifies that it takes two parameters
    //check number of arguments
    if(argc != 2){//check number of argument if not = 2
        std::cerr << "Usage: sortedverification file.json" << std::endl;//then it will print this messge out
        exit(-1);//exit
    }//end if

    std::string filename = argv[1];//name of file
    //std::string filename = "Example1.json";
    //std::string filename = "SampleExample.json";
    std::ifstream file(filename);//read stream for file
    nlohmann::json in_json;//read json for file
    nlohmann::json out_json;//out json
    //check if the file opens right
    if(file.is_open()){//if file is opened
        file >> in_json;//take the information to json
    }//end if
    else{//else
        std::cerr << "Error: cannot open file " << filename << std::endl;//else we cannot open the file
    }//end else

    file.close();//close file
    //basic information for file to out_json
    out_json["metadata"]["arraySize"] = in_json["metadata"]["arraySize"];//print size
    out_json["metadata"]["numSamples"] = in_json["metadata"]["numSamples"];//print numsamples
    out_json["metadata"]["file"] = filename;//print filename
    int n = in_json["metadata"]["arraySize"];//array size
    int samplesWithInversions = 0;//samples with inversions
    //interate json
    for(auto itr = in_json.begin(); itr != in_json.end(); itr++){//itr from begin to end then itr ++
        //check sample
        if(itr.key()[0] == 'S'){//check sample
            std::vector<int> sample;//statement
            //get value to vector
            for(auto e : itr.value()){//get value to vector
                sample.push_back(e);//push back
            }//end for loop
            //check if the vector is sorted
            if(!isSorted(sample)){//check if the vector is sorted
                samplesWithInversions++;//add inversion
                for(int i = 0; i < n - 1; i++){//claim i if i smaller than n-1 then i+1
                    if(sample[i] >= sample[i + 1]){//exmaple:sample[1]>sample[2]
                        std::array<int, 2> consecutiveInversions;//get consecutive inversion
                        consecutiveInversions[0] = sample[i];//if statement work then conduct this assginment
                        consecutiveInversions[1] = sample[i + 1];//if statement work then conduct this assginment
                        out_json[itr.key()]["ConsecutiveInversions"][std::to_string(i)] = consecutiveInversions;//put inversion to out json
                    }//end if
                }//end for
                out_json[itr.key()]["sample"] = itr.value();//The value of the key-value pair being added is specified by the expression "itr.value()".
            }//end if
        }//end if
    }//end for
    out_json["metadata"]["samplesWithInversions"] = samplesWithInversions;//returns the value associated with the specified key-value pair.
    std::cout << out_json.dump(2) << std::endl;//output result
    return 0;//main function typically indicates successful execution
}
