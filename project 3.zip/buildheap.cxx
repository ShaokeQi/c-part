#include "priorityqueue.h"
#include "json.hpp"
#include <iostream>
#include <fstream>

int main(int argc, char** argv) {//check number of arguments
    //check number of arguments
    if(argc != 2){//check 
        std::cerr << "Usage: buildheap file.json" << std::endl;//error message
        exit(-1);//exits the program with non-zero status code
    }

    std::string filename = argv[1]; //name of file
    
    std::ifstream file(filename); //read stream for file
    nlohmann::json in_json; //read json for file
    nlohmann::json out_json; //out json
	//check if the file opens right
    if(file.is_open()){//check file is open or not
        file >> in_json; //read file
    }//end if 
    else{//else statement
        std::cerr << "Error: cannot open file " << filename << std::endl;//error message
		exit(-1);//exits the program with non-zerp status code
    }//end else statement
    int maxHeapSize = in_json["metadata"]["maxHeapSize"];//retrieves the value of the maxHeapSize field in the metadata object and stores it in an integer variable called maxHeapSize
    int numOperations = in_json["metadata"]["numOperations"];//retrieves the value of the numOperations field in the metadata object and stores it in an integer variable called numOperations.
    PriorityQueue q(maxHeapSize);
    for(auto itr = in_json.begin(); itr != in_json.end(); itr++){//loop iterates through all the elements in the in_json object
		//check sample
        if(itr.key()[0] == 'O'){//it checks if the key of the element starts with the character "O"
            if(itr.value()["operation"] == "insert"){// retrieves the value of the key field and inserts it into the heap.
                q.insert(static_cast<Key>(itr.value()["key"]));//retrieves the value of the key field and inserts it into.
            }//end if statement
            if(itr.value()["operation"] == "removeMin"){//If the operation is "removeMin"
                q.removeMin();//remove the min
            }//end if statement
        }//end if statement
    }//end for statement
    out_json = q.JSON();//represents the current state of the heap
    out_json["metadata"]["maxHeapSize"] = maxHeapSize;//maxHeapSize object to their original values
    out_json["metadata"]["numOperations"] = numOperations;//numOperations object to their original values
    std::cout << out_json.dump(2) << std::endl;//object to the standard output stream
}//end main
