#include "priorityqueue.h"
#include "json.hpp"
#include <iostream>
#include <fstream>
#include <vector>

int main(int argc, char** argv) {//check number of arguments
    
    
    if(argc != 2){//check the argument if is not 2
        std::cerr << "Usage: createteams file.json" << std::endl;//error message
        exit(-1);//just exit
    }//end if statemnt

    std::string filename = argv[1]; //name of file
    
    std::ifstream file(filename); //read stream for file
    nlohmann::json in_json; //read json for file
    nlohmann::json out_json; //out json
	//check if the file opens right
    if(file.is_open()){//check file is open or not
        file >> in_json; //read file
    }//end if statement
    else{//else statemnt
        std::cerr << "Error: cannot open file " << filename << std::endl;//error message
		exit(-1);//exit with non0
    }//end else statement
    int n = in_json["metadata"]["numPlayers"];//The retrieved value is then stored in the n variable.
    int idx = 0;//just index = 0
    PriorityQueue q(n * (n - 1) / 2);//method of use
    out_json["teams"] = std::vector<KeyValuePair>(n / 2);//two as team then total teams
    std::vector<bool> assigned(n, 0);//Initialization
    for(auto itr = in_json["teamStats"].begin(); itr != in_json["teamStats"].end(); itr++){//read teams information
        KeyValuePair e(fabs(50.0 - static_cast<double>(itr.value()["winPercentage"])), {itr.value()["playerOne"], itr.value()["playerTwo"]});//this one is calculate the win percentage of each team. if the value is more smaller which means it's more colse to the 50
        q.insert(e);//inserting a new key-value pair into the PriorityQueue object q
    }//end for loop

   while(idx < n/2){//while idk smaller than the total teams it will continues in the while
    KeyValuePair e = q.removeMin();//assignment
    if(assigned[e.second.first] == 0 && assigned[e.second.second] == 0){//this one just to mark
            out_json["teams"][idx] = e.second;//inside the loop, the code removes the team with the smallest absolute difference from the PriorityQueue object q using the PriorityQueue::removeMin method, and assigns the resulting KeyValuePair object to a new variable e.
            idx++;//add 
            assigned[e.second.first] = assigned[e.second.second] = 1;//if = 1 it will be removed
        }//edn if statement
    }//end while
    std::cout << out_json.dump(2) << std::endl;//the code prints the resulting
}//end main
