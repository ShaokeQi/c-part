#include <iostream>
#include "json.hpp"

#include "priorityqueue.h"

PriorityQueue::PriorityQueue(std::size_t max_size) ://The constructor first initializes a std::vector object nodes_ of size max_size+1 with default-initialized KeyValuePair objects.
	nodes_(max_size + 1, KeyValuePair()),//The constructor first initializes a std::vector object nodes_ of size max_size+1 with default-initialized KeyValuePair objects.
	max_size_(max_size),//The constructor first initializes a std::vector object nodes_ of size max_size+1 with default-initialized KeyValuePair objects.
	size_(0) {//The constructor first initializes a std::vector object nodes_ of size max_size+1 with default-initialized KeyValuePair objects.
}//This is because the heap-based implementation of the priority queue requires an extra element at the root of the heap to simplify the implementation of some of the methods.

void PriorityQueue::insert(Key k) {//This method allows the user to insert a key into the priority queue without specifying a value.
	insert(std::make_pair(k, std::make_pair(0, 0)));//creates a new KeyValuePair object with a key k and a value consisting of a pair of two 0s.
}//end

void PriorityQueue::insert(KeyValuePair kv) {//insert
	// TODO: complete this function
	//if the size is max
	if(size_ == max_size_){//if the size is max
        return;//return
	}//end if
    nodes_[++size_] = kv;//inserts the new element into the last position of the nodes_ array.
    heapifyUp(size_);//method to ensure that the heap property is maintained
}//end function

KeyValuePair PriorityQueue::min() {//thie function return the min value
	// TODO: complete this function
	return nodes_[1];//get the top node
}//end fucntion

KeyValuePair PriorityQueue::removeMin() {// thie function removes and return minmum value
	// TODO: complete this function
	KeyValuePair e = nodes_[1];//sets the value of e to the first element in node_, which is the minimum value
	removeNode(1);//this line removes the first element in the node_ vector
	return e;//return the value that was removed
}//end function

bool PriorityQueue::isEmpty() const {//this fucntion return a boolean value
	// TODO: complete this function
	return (size_ == 0);//return ture if the size of queue is zero
}//end fucntion

size_t PriorityQueue::size() const {//this functiton return the current size of priority queue
	// TODO: complete this function
	return size_;//this line returns the value of the size_ variable which is the number of elements currently in the queue
}//end of fucntion

nlohmann::json PriorityQueue::JSON() const {//fucntion
	nlohmann::json result;//create a new Json object
  for (size_t i = 1; i <= size_; i++) {//loops through each node in the priority
      nlohmann::json node;//
      KeyValuePair kv = nodes_[i];//
      node["key"] = kv.first;//set its value to the key of the current node
      node["value"] = kv.second;//value to its current node
      if (i != ROOT) {//if it is not current node
          node["parent"] = std::to_string(i / 2);//its value to the index of the parent node(whcih is calculated as i/2)
      }//end if
      if (2 * i <= size_) {//if current node has a left child,
          node["leftChild"] = std::to_string(2 * i);//add a key called left child to json object and set it value
      }//end if
      if (2 * i + 1 <= size_) {//sets its value to the index of the right child node (which is calculated as 2*i+1
          node["rightChild"] = std::to_string(2 * i + 1);//add a key called right child to json object and set it value
      }//end if
      result[std::to_string(i)] = node;//add the json object for the current node to the result object
  }//end for
  result["metadata"]["max_size"] = max_size_;//adds a key called "max_size" to the "metadata" object in the "result" object and sets its value to the maximum size of the priority queue.
  result["metadata"]["size"] = size_;//adds a key called "size" to the "metadata" object in the "result" object and sets its value to the current size of the priority queue.
	return result;//return 
}//end function

void PriorityQueue::heapifyUp(size_t i) {//function
	// TODO: complete this function
	//up until no change happens
	while(i > 1 && nodes_[i].first < nodes_[i / 2].first){// i is not at the root node and the key of the node at index i is less than the key of its parent node
        std::swap(nodes_[i], nodes_[i / 2]);//swaps the node at index i with its parent node (which is at index i / 2) in order to restore the heap property.
        i >>= 1;//divide by 2
	}//end while
}//end function

void PriorityQueue::heapifyDown(size_t i) {//fucntion
	// TODO: complete this function
	while(i * 2 <= size_){//this line is a while loop tha tcontinuese as long as the left child of the node being heapified which i*2 is less htan ot equal size of heap
        size_t min_child = i * 2;//iniializing avariable min child to the index of the left child of the node being heapified
        //choose a smaller child
        if(i * 2 + 1 <= size_){//checing wheter the node being heapified has a right child
            if(nodes_[i * 2 + 1].first < nodes_[i * 2].first){//This line is checking whether the right child is smaller than the left child.
                min_child = i * 2 + 1;//it is, then min_child is set to the index of the right child
            }//end if 
        }//end if 
        //compare it with ith node
        if(nodes_[min_child].first < nodes_[i].first){//compare it with ith node
            std::swap(nodes_[min_child], nodes_[i]);//if ture swap
            i = min_child;//set minchild to i
        }//end if 
        //no change happens
        else{//else statement
            break;//break
        }//end else 
	}// end while
}//end function

void PriorityQueue::removeNode(size_t i) {
	// TODO: complete this function
	//if wrong i
	if(i > size_){//if wrong i
        return;//return
	}//end if 
	//if i is the last index
	if(i == size_){//if i is the last index
        size_--;//--
        return;//return
	}
	//if i is not the last node
    std::swap(nodes_[i], nodes_[size_]);//if i is not the last node
    size_--;//--
    heapifyDown(i);//function to restore the heap property starting from index i
}//end function

Key PriorityQueue::getKey(size_t i) {//fucntion
	// TODO: complete this function
	return nodes_[i].first;//return key
}//end fucntion
